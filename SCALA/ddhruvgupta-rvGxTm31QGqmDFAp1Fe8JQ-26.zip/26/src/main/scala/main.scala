def singleDigit(num: Int) : Int ={
    var sum = num % 9
    if(sum == 0 && num > 0) 9
  sum
}



print(singleDigit(9876543));

